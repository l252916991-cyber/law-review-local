"""Adapter for OpenAI-compatible chat-completions endpoints."""

from __future__ import annotations

import json
from typing import Any
from urllib.parse import urlparse

import httpx
from pydantic import BaseModel, ConfigDict, Field, ValidationError

from forgeharness.domain.models import (
    AgentAction,
    FinalAction,
    Message,
    ModelResult,
    ModelUsage,
    ToolAction,
    ToolCall,
)
from forgeharness.models.base import ModelProtocolError as SharedModelProtocolError
from forgeharness.models.base import ModelRequest
from forgeharness.models.prepared import (
    PreparedModelCall,
    canonical_json,
    chat_inputs,
    chat_message,
)

_LOOPBACK_HOSTS = frozenset({"127.0.0.1", "localhost", "::1"})


def _is_loopback(base_url: str) -> bool:
    """True when the endpoint is a loopback host, where a proxy is never correct."""
    host = urlparse(base_url).hostname
    return host in _LOOPBACK_HOSTS


class ModelProtocolError(SharedModelProtocolError):
    """Adapter-local name for the shared protocol violation contract.

    Kept as a subclass so existing imports keep working, while the runtime can
    still catch the provider-neutral base class without importing this module.
    """


class OpenAICompatibleConfig(BaseModel):
    """Validated configuration for an OpenAI-compatible endpoint."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    base_url: str
    api_key: str = Field(min_length=1)
    model: str = Field(min_length=1)
    timeout_seconds: float = Field(default=120.0, gt=0)
    temperature: float = Field(default=0.0, ge=0, le=2)
    max_tokens: int | None = Field(default=None, ge=1, le=32_768)
    enable_thinking: bool | None = None
    context_window_tokens: int | None = Field(default=None, ge=1)
    provider_overhead_tokens: int | None = Field(default=None, ge=0)


class _FunctionCall(BaseModel):
    model_config = ConfigDict(extra="ignore")

    name: str
    arguments: str


class _RemoteToolCall(BaseModel):
    model_config = ConfigDict(extra="ignore")

    id: str
    type: str = "function"
    function: _FunctionCall


class _AssistantMessage(BaseModel):
    model_config = ConfigDict(extra="ignore")

    content: str | None = None
    tool_calls: list[_RemoteToolCall] = Field(default_factory=list)


class _Choice(BaseModel):
    model_config = ConfigDict(extra="ignore")

    message: _AssistantMessage


class _RemoteUsage(BaseModel):
    model_config = ConfigDict(extra="ignore")

    prompt_tokens: int = 0
    completion_tokens: int = 0


class _ChatCompletion(BaseModel):
    model_config = ConfigDict(extra="ignore")

    model: str = "unknown"
    choices: list[_Choice]
    usage: _RemoteUsage = _RemoteUsage()


class OpenAICompatibleModel:
    """Translate Harness messages and tools to chat-completions requests."""

    def __init__(
        self, config: OpenAICompatibleConfig, *, client: httpx.AsyncClient | None = None
    ) -> None:
        self._config = config
        if client is not None:
            self._client = client
            return
        # A desktop HTTP proxy must never intercept a loopback endpoint: the
        # proxy cannot reach 127.0.0.1 and answers 502. Remote endpoints keep
        # `trust_env` so corporate proxy configuration still applies. This
        # mirrors OMLXClient and the other local clients in this repository.
        self._client = httpx.AsyncClient(
            timeout=config.timeout_seconds, trust_env=not _is_loopback(config.base_url)
        )

    async def decide(self, request: ModelRequest) -> ModelResult:
        """Request and validate exactly one final answer or tool call."""
        return await self.decide_prepared(self.prepare_request(request))

    def prepare_request(self, request: ModelRequest) -> PreparedModelCall:
        """Freeze the exact credential-free body that the transport will send."""
        return PreparedModelCall(
            request_json=canonical_json(request.model_dump(mode="json")),
            payload_json=canonical_json(self._request_body(request)),
            format="chat-completions-v1",
            output_limit=self._config.max_tokens,
            context_window=self._config.context_window_tokens,
            provider_overhead_tokens=self._config.provider_overhead_tokens,
        )

    async def decide_prepared(self, prepared: PreparedModelCall) -> ModelResult:
        """Send the admitted snapshot rather than regenerating its messages or schema."""
        if prepared.format != "chat-completions-v1":
            raise ValueError("unexpected prepared request format")
        response = await self._client.post(
            f"{self._config.base_url.rstrip('/')}/chat/completions",
            headers={
                "Authorization": f"Bearer {self._config.api_key}",
                "Content-Type": "application/json",
            },
            content=prepared.payload_json.encode(),
            timeout=self._config.timeout_seconds,
        )
        response.raise_for_status()
        try:
            completion = _ChatCompletion.model_validate(response.json())
        except (ValidationError, ValueError) as exc:
            raise ModelProtocolError(f"invalid chat-completions response: {exc}") from exc
        if len(completion.choices) != 1:
            raise ModelProtocolError(
                f"expected exactly one completion choice, got {len(completion.choices)}"
            )
        remote_message = completion.choices[0].message
        if len(remote_message.tool_calls) > 1:
            # A recoverable model-protocol violation, surfaced as such so the
            # caller can decide how to handle it rather than losing the reason.
            raise ModelProtocolError(
                "parallel tool calls are not enabled for this runtime",
                code="multiple_tool_calls_not_allowed",
                received_tool_calls=len(remote_message.tool_calls),
                # The request consumed these tokens, so a run that retries must
                # still be charged for the rejected attempt.
                usage=ModelUsage(
                    input_tokens=completion.usage.prompt_tokens,
                    output_tokens=completion.usage.completion_tokens,
                ),
            )
        action: AgentAction
        if remote_message.tool_calls:
            action = ToolAction(call=self._parse_tool_call(remote_message.tool_calls[0]))
        elif remote_message.content is not None:
            action = FinalAction(content=remote_message.content)
        else:
            raise ModelProtocolError("completion contained neither content nor a tool call")
        return ModelResult(
            action=action,
            model_name=completion.model,
            usage=ModelUsage(
                input_tokens=completion.usage.prompt_tokens,
                output_tokens=completion.usage.completion_tokens,
            ),
        )

    def _request_body(self, request: ModelRequest) -> dict[str, Any]:
        body: dict[str, Any] = {
            "model": self._config.model,
            "temperature": self._config.temperature,
            **chat_inputs(request),
        }
        if self._config.max_tokens is not None:
            body["max_tokens"] = self._config.max_tokens
        if self._config.enable_thinking is not None:
            body["chat_template_kwargs"] = {"enable_thinking": self._config.enable_thinking}
        return body

    @staticmethod
    def _serialize_message(message: Message) -> dict[str, Any]:
        return chat_message(message)

    @staticmethod
    def _parse_tool_call(remote: _RemoteToolCall) -> ToolCall:
        if remote.type != "function":
            raise ModelProtocolError(f"unsupported tool-call type: {remote.type}")
        try:
            arguments = json.loads(remote.function.arguments)
        except json.JSONDecodeError as exc:
            raise ModelProtocolError(f"tool arguments are not valid JSON: {exc.msg}") from exc
        if not isinstance(arguments, dict):
            raise ModelProtocolError("tool arguments must decode to an object")
        try:
            return ToolCall(id=remote.id, name=remote.function.name, arguments=arguments)
        except ValidationError as exc:
            raise ModelProtocolError(f"invalid tool call: {exc}") from exc
